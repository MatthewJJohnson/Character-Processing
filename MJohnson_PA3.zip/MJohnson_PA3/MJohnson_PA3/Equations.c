/*
Programmer: Matthew J Johnson
Class: CptS 121, Spring  2016; Lab Section-09
Programming Assignment: Programming Assignment Three
Date: February 6, 2016
Description: This program performs character processing on 10 characters read in from a file, and writes the results to output files.
Collaborators: None
Revision History:	-Created 2:6:16
*/

#include "Equations.h"

/*************************************************************
* Function: FILE * open_input_file(void)
* Date Created:        2:6:16
* Date Last Modified:      2:6:16
* Description:     This Program Opens "input.dat" for reading
* Input parameters:		none
* Returns:				infile
* Preconditions:  input.dat must exist
* Postconditions:  infile is returned
*************************************************************/
FILE * open_input_file(void)
{
	FILE*infile = NULL;
	infile = fopen("input.dat", "r");
	return infile;
}

/*************************************************************
* Function: FILE * open_output_stats_file(void)
* Date Created:        2:6:16
* Date Last Modified:      2:6:16
* Description:     This Program Opens "output_stats.dat" for writing
* Input parameters:		none
* Returns:				outfile_stats
* Preconditions:  none
* Postconditions:  outfile_stats is returned
*************************************************************/
FILE * open_output_stats_file(void)
{
	FILE*outfile_stats = NULL;
	outfile_stats = fopen("output_stats.dat", "w");
	return outfile_stats;
}

/*************************************************************
* Function: FILE * open_output_stats_file(void)
* Date Created:        2:6:16
* Date Last Modified:      2:6:16
* Description:     This Program Opens "output_ascii.dat" for writing
* Input parameters:		none
* Returns:				outfile_stats
* Preconditions:  none
* Postconditions:  outfile_stats is returned
*************************************************************/
FILE * open_output_ascii_file(void)
{
	FILE*outfile_ascii = NULL;
	outfile_ascii = fopen("output_ascii.dat", "w");
	return outfile_ascii;
}

/*************************************************************
* Function: char read_character(FILE *infile)
* Date Created:        2:6:16
* Date Last Modified:      2:6:16
* Description:     This program Reads one character from the input file
* Input parameters:		infile
* Returns:				character
* Preconditions:  infile must be opened.
* Postconditions:  character is returned as a character
*************************************************************/
char read_character(FILE *infile)
{
	char character = '\0';
	fscanf(infile, "%c", &character);
	return character;
}

/*************************************************************
* Function: char read_character(FILE *infile)
* Date Created:        2:6:16
* Date Last Modified:      2:6:16
* Description:     This program Reads one character from the input file
* Input parameters:		infile
* Returns:				ASCII_character
* Preconditions:  infile must be opened.
* Postconditions:  ASCII_character is returned as an integer
*************************************************************/
int determine_ascii_value(char character)
{
	int ASCII_character = 0;
	ASCII_character = character;
	return ASCII_character;
}

/*************************************************************
* Function: int is_line(char character)
* Date Created:        2:6:16
* Date Last Modified:      2:6:16
* Description:     This program Determines if the character is a newline, 
if the character is a newline a 1 is returned otherwise a 0 is returned.
* Input parameters:		character
* Returns:				lineresult
* Preconditions:  infile must be opened.
* Postconditions:  lineresult is returned as a 1 or 0
*************************************************************/
int is_line(char character)
{
	int lineresult = NOT_NEWLINE;
	if (character == '\n')
	{
		lineresult = NEWLINE;
	}
	return lineresult;
}

/*************************************************************
* Function: int number_lines(char character, int current_number_lines)
* Date Created:        2:6:16
* Date Last Modified:      2:6:16
* Description:     This program Determines if the character is an end of line,
if the character is an end of line a 1 is added otherwise current_number_lines is returned unchanged.
* Input parameters:		character, current_number_lines
* Returns:				numberlineresult (+1) or numberlineresult
* Preconditions:  infile must be opened.
* Postconditions:  numberlineresult is returned as an integer.
*************************************************************/
int number_lines(char character, int current_number_lines)
{
	int numberlineresult = 0;
	numberlineresult = is_line(character);

		if (numberlineresult == NEWLINE)
		{
			current_number_lines += 1;
		}
		return current_number_lines;
}

/*************************************************************
* Function: int is_vowel(char character)
* Date Created:        2:8:16
* Date Last Modified:      2:8:16
* Description:     This program Determines if the character is a vowel,
if the character is a vowel a 2 is returned otherwise a 0 is returned.
* Input parameters:		character
* Returns:				vowelresult
* Preconditions:  infile must be opened.
* Postconditions:  vowelresult is returned as a 2 or 0
*************************************************************/
int is_vowel(char character)
{
	int vowelresult = NOT_VOWEL;
	if (character == 'A')
	{
		vowelresult = VOWEL;
	}
	else if (character == 'E')
	{
		vowelresult = VOWEL;
	}
	else if (character == 'I')
	{
		vowelresult = VOWEL;
	}
	else if (character == 'O')
	{
		vowelresult = VOWEL;
	}
	else if (character == 'U')
	{
		vowelresult = VOWEL;
	}
	else if (character == 'a')
	{
		vowelresult = VOWEL;
	}
	else if (character == 'e')
	{
		vowelresult = VOWEL;
	}
	else if (character == 'i')
	{
		vowelresult = VOWEL;
	}
	else if (character == 'o')
	{
		vowelresult = VOWEL;
	}
	else if (character == 'u')
	{
		vowelresult = VOWEL;
	}
	return vowelresult;
}

/*************************************************************
* Function: int number_lines(char character, int current_number_vowels)
* Date Created:        2:8:16
* Date Last Modified:      2:8:16
* Description:     This program Determines if the character is a vowel,
if the character is a vowel a 1 is added to the current_number_vowels and is returned.
* Input parameters:		character, current_number_lines
* Returns:				numbervowels (+1) or numbervowels
* Preconditions:  infile must be opened.
* Postconditions:  current_number_vowels is returned as an integer.
*************************************************************/
int number_vowels(char character, int current_number_vowels)
{
	int numbervowels = 0;
	numbervowels = is_vowel(character);

	if (numbervowels == VOWEL)
	{
		current_number_vowels += 1;
	}
	return current_number_vowels;
}

/*************************************************************
* Function: int is_digit(char character)
* Date Created:        2:8:16
* Date Last Modified:      2:8:16
* Description:     This program Determines if the character is a number,
if the character is a number a 3 is returned otherwise a 0 is returned.
* Input parameters:		character
* Returns:				digitresult
* Preconditions:  infile must be opened.
* Postconditions:  digitresult is returned as a 3 or 0
*************************************************************/
int is_digit(char character)
{
	int digitresult = NOT_NUMBER;
	if ((character >= '0') && (character <= '9'))
	{
		digitresult = NUMBER;
	}
	return digitresult;
}

/*************************************************************
* Function: int number_vowels(char character, int current_number_vowels)
* Date Created:        2:8:16
* Date Last Modified:      2:8:16
* Description:     This program Determines if the character is a digit,
if the character is a number a 1 is added to the current_number_digit and is returned.
* Input parameters:		character, current_number_digits
* Returns:				numberdigit (+1) or numberdigit
* Preconditions:  infile must be opened.
* Postconditions:  current_number_digits is returned as an integer.
*************************************************************/
int number_digits(char character, int current_number_digits)
{
	int numberdigit = NOT_NUMBER;
	numberdigit = is_digit(character);

	if (numberdigit == NUMBER)
	{
		current_number_digits += 1;
	}
	return current_number_digits;
}

/*************************************************************
* Function: int is_alpha(char character)
* Date Created:        2:8:16
* Date Last Modified:      2:8:16
* Description:     This program Determines if the character is an alpha,
if the character is an alpha a 4 is returned otherwise a 0 is returned.
* Input parameters:		character
* Returns:				alpharesult
* Preconditions:  infile must be opened.
* Postconditions:  alpharesult is returned as a 4 or 0
*************************************************************/
int is_alpha(char character)
{
	int alpharesult = NOT_ALPHA;
	if (((character >= 'A') && (character <= 'Z')) || ((character >= 'a') && (character <= 'z')))
	{
		alpharesult = ALPHA;
	}
	return alpharesult;
}

/*************************************************************
* Function: int number_alphas(char character, int current_number_alphas)
* Date Created:        2:8:16
* Date Last Modified:      2:8:16
* Description:     This program Determines if the character is an alpha,
if the character is an alpha a 1 is added to the current_number_alpha and is returned.
* Input parameters:		character, current_number_alphas
* Returns:				numberalpha (+1) or numberalpha
* Preconditions:  infile must be opened.
* Postconditions:  current_number_alphas is returned as an integer.
*************************************************************/
int number_alphas(char character, int current_number_alphas)
{
	int numberalphas = NOT_ALPHA;
	numberalphas = is_alpha(character);

	if (numberalphas == ALPHA)
	{
		current_number_alphas += 1;
	}
	return current_number_alphas;
}

/*************************************************************
* Function: int is_lower(char character)
* Date Created:        2:8:16
* Date Last Modified:      2:8:16
* Description:     This program Determines if the character is a lowercase character,
if the character is a lowercase a 5 is returned otherwise a 0 is returned.
* Input parameters:		character
* Returns:				lowerresult
* Preconditions:  infile must be opened.
* Postconditions:  lowerresult is returned as a 5 or 0
*************************************************************/
int is_lower(char character)
{
	int lowerresult = NOT_LOWER;
	if ((character >= 'a') && (character <= 'z'))
	{
		lowerresult = LOWER;
	}
	return lowerresult;
}

/*************************************************************
* Function: int number_lowers(char character, int current_number_lowers)
* Date Created:        2:8:16
* Date Last Modified:      2:8:16
* Description:     This program Determines if the character is a lowercase,
if the character is a lowercase a 1 is added to the current_number_lowers and is returned.
* Input parameters:		character, current_number_lowers
* Returns:				numberlowers (+1) or numberlowers
* Preconditions:  infile must be opened.
* Postconditions:  numberlowers is returned as an integer.
*************************************************************/
int number_lowers(char character, int current_number_lowers)
{
	int numberlowers = NOT_LOWER;
	numberlowers = is_lower(character);

	if (numberlowers == LOWER)
	{
		current_number_lowers += 1;
	}
	return current_number_lowers;
}

/*************************************************************
* Function: int is_upper(char character)
* Date Created:        2:8:16
* Date Last Modified:      2:8:16
* Description:     This program Determines if the character is an uppercase character,
if the character is an uppercase a 6 is returned otherwise a 0 is returned.
* Input parameters:		character
* Returns:				upperresult
* Preconditions:  infile must be opened.
* Postconditions:  upperresult is returned as a 6 or 0
*************************************************************/
int is_upper(char character)
{
	int upperresult = NOT_UPPER;
	if ((character >= 'A') && (character <= 'Z'))
	{
		upperresult = UPPER;
	}
	return upperresult;
}

/*************************************************************
* Function: int number_uppers(char character, int current_number_uppers)
* Date Created:        2:8:16
* Date Last Modified:      2:8:16
* Description:     This program Determines if the character is a uppercase,
if the character is a uppercase a 1 is added to the current_number_uppers and is returned.
* Input parameters:		character, current_number_uppers
* Returns:				numberuppers (+1) or numberuppers
* Preconditions:  infile must be opened.
* Postconditions:  current_number_uppers is returned as an integer.
*************************************************************/
int number_uppers(char character, int current_number_uppers)
{
	int numberuppers = NOT_UPPER;
	numberuppers = is_upper(character);

	if (numberuppers == UPPER)
	{
		current_number_uppers += 1;
	}
	return current_number_uppers;
}

/*************************************************************
* Function: int is_space(char character)
* Date Created:        2:8:16
* Date Last Modified:      2:8:16
* Description:     This program Determines if the character is a whitespace character,
if the character is a whitespace a 7 is returned otherwise a 0 is returned.
* Input parameters:		character
* Returns:				whitespaceresult
* Preconditions:  infile must be opened.
* Postconditions:  whitespaceresult is returned as a 7 or 0
*************************************************************/
int is_space(char character)
{
	int whitespaceresult = NOT_WHITESPACE;
	if (character == ' ')
	{
		whitespaceresult = WHITESPACE;
	}
	else if (character == '\f')
	{
		whitespaceresult = WHITESPACE;
	}
	else if (character == '\n')
	{
		whitespaceresult = WHITESPACE;
	}
	else if (character == '\r')
	{
		whitespaceresult = WHITESPACE;
	}
	else if (character == '\t')
	{
		whitespaceresult = WHITESPACE;
	}
	else if (character == '\v')
	{
		whitespaceresult = WHITESPACE;
	}
	else if (character == '	')
	{
		whitespaceresult = WHITESPACE;
	}
	return whitespaceresult;
}

/*************************************************************
* Function: int number_spaces(char character, int current_number_spaces)
* Date Created:        2:8:16
* Date Last Modified:      2:8:16
* Description:     This program Determines if the character is a whitespace,
if the character is a whitespace a 1 is added to the current_number_spaces and is returned.
* Input parameters:		character, current_number_spaces
* Returns:				numberwhitespaces (+1) or numberwhitespaces
* Preconditions:  infile must be opened.
* Postconditions:  current_number_spaces is returned as an integer.
*************************************************************/
int number_spaces(char character, int current_number_spaces)
{
	int numberwhitespaces = NOT_WHITESPACE;
	numberwhitespaces = is_space(character);

	if (numberwhitespaces == WHITESPACE)
	{
		current_number_spaces += 1;
	}
	return current_number_spaces;
}

/*************************************************************
* Function: int is_alnum(char character)
* Date Created:        2:8:16
* Date Last Modified:      2:8:16
* Description:     This program Determines if the character is an alnum,
if the character is an alnum a 8 is returned otherwise a 0 is returned.
* Input parameters:		character
* Returns:				alnumresult
* Preconditions:  infile must be opened.
* Postconditions:  alnumresult is returned as an 8 or 0
*************************************************************/
int is_alnum(char character)
{
	int alnumresult = NOT_ALNUM;
	if (((character >= 'A') && (character <= 'Z')) || ((character >= 'a') && (character <= 'z')) || ((character >= '0') && (character <= '9')))
	{
		alnumresult = ALNUM;
	}
	return alnumresult;
}

/*************************************************************
* Function: int number_alnums(char character, int current_number_alnums)
* Date Created:        2:8:16
* Date Last Modified:      2:8:16
* Description:     This program Determines if the character is an alnum,
if the character is an alnum a 1 is added to the current_number_alnums and is returned.
* Input parameters:		character, current_number_spaces
* Returns:				numberalnums (+1) or numberalnums
* Preconditions:  infile must be opened.
* Postconditions:  current_number_alnums is returned as an integer.
*************************************************************/
int number_alnums(char character, int current_number_alnums)
{
	int numberalnums = NOT_ALNUM;
	numberalnums = is_alnum(character);

	if (numberalnums == ALNUM)
	{
		current_number_alnums += 1;
	}
	return current_number_alnums;
}

/*************************************************************
* Function: int is_punct(char character)
* Date Created:        2:8:16
* Date Last Modified:      2:8:16
* Description:     This program Determines if the character is a punctuation character,
if the character is a punctuation a 7 is returned otherwise a 0 is returned.
* Input parameters:		character
* Returns:				punctuationresult
* Preconditions:  infile must be opened.
* Postconditions:  punctuationresult is returned as a 9 or 0
*************************************************************/
int is_punct(char character)
{
	int punctuationresult = NOT_PUNCT;
	if (character == '!')
	{
		punctuationresult = PUNCT;
	}
	else if (character == '.')
	{
		punctuationresult = PUNCT;
	}
	else if (character == ',')
	{
		punctuationresult = PUNCT;
	}
	else if (character == ':')
	{
		punctuationresult = PUNCT;
	}
	else if (character == ';')
	{
		punctuationresult = PUNCT;
	}
	else if (character == '-')
	{
		punctuationresult = PUNCT;
	}
	else if (character == '?')
	{
		punctuationresult = PUNCT;
	}
	else if (character == '&')
	{
		punctuationresult = PUNCT;
	}
	return punctuationresult;
}

/*************************************************************
* Function: int number_spaces(char character, int current_number_spaces)
* Date Created:        2:9:16
* Date Last Modified:      2:9:16
* Description:     This program Determines if the character is a punctuation,
if the character is a punctuation a 1 is added to the current_number_puncts and is returned.
* Input parameters:		character, current_number_puncts
* Returns:				numberpuncts (+1) or numberpuncts
* Preconditions:  infile must be opened.
* Postconditions:  current_number_puncts is returned as an integer.
*************************************************************/
int number_puncts(char character, int current_number_puncts)
{
	int numberpuncts = NOT_PUNCT;
	numberpuncts = is_punct(character);

	if (numberpuncts == PUNCT)
	{
		current_number_puncts += 1;
	}
	return current_number_puncts;
}

/*************************************************************
* Function: void print_int(FILE *outfile_ascii, int number)
* Date Created:        2:9:16
* Date Last Modified:      2:9:16
* Description:     This program prints an integer to an output file.
* Input parameters:		ASCII_character
* Returns:				
* Preconditions:  outfile must be opened.
* Postconditions:  outfile stores a number.
*************************************************************/
void print_int(FILE *outfile_ascii, int ASCII_character)
{
	fprintf(outfile_ascii, "%d\n", ASCII_character);
}

/*************************************************************
* Function: void print_stats(FILE *outfile_stats, char header[], int number)
* Date Created:        2:9:16
* Date Last Modified:      2:9:16
* Description:     This program prints a stat line to t a output file.
* Input parameters:		a string and an integer
* Returns:
* Preconditions:  outfile must be opened.
* Postconditions:  outfile stores a number.
*************************************************************/
void print_stats(FILE *outfile_stats, char header[], int number)
{
	fprintf(outfile_stats, "%s %d\n", header, number);;
}

