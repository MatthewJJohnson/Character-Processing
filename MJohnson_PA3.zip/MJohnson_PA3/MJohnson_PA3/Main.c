/*
Programmer: Matthew J Johnson
Class: CptS 121, Spring  2016; Lab Section-09
Programming Assignment: Programming Assignment Three
Date: February 6, 2016
Description: This program performs character processing on 10 characters read in from a file, and writes the results to output files.
Collaborators: None
Revision History:	-Created 2:6:16
					-Continued from is_line() on 2:8:16
					-Continued from print_int() on 2:9:16
					-Made in class corrections and finalization on 2:10:16
*/

#include "Equations.h"

int main(void)
{
	FILE *infile = NULL, *outfile_ascii = NULL, *outfile_stats = NULL;
	int ASCII_character = 0, current_number_lines = 0, current_number_vowels = 0, current_number_digits = 0, current_number_alphas = 0;
	int current_number_lowers = 0, current_number_uppers = 0, current_number_spaces = 0, current_number_alnums = 0, current_number_puncts = 0;
	char character = '\0';

	infile = open_input_file();
	outfile_ascii = open_output_ascii_file();
	outfile_stats = open_output_stats_file();

	character = read_character(infile);
	ASCII_character = determine_ascii_value(character);
	current_number_lines = number_lines(character, current_number_lines);
	current_number_vowels = number_vowels(character, current_number_vowels);
	current_number_digits = number_digits(character, current_number_digits);
	current_number_alphas = number_alphas(character, current_number_alphas);
	current_number_lowers = number_lowers(character, current_number_lowers);
	current_number_uppers = number_uppers(character, current_number_uppers);
	current_number_spaces = number_spaces(character, current_number_spaces);
	current_number_alnums = number_alnums(character, current_number_alnums);
	current_number_puncts = number_puncts(character, current_number_puncts);
	print_int(outfile_ascii, ASCII_character);

	character = read_character(infile);
	ASCII_character = determine_ascii_value(character);
	current_number_lines = number_lines(character, current_number_lines);
	current_number_vowels = number_vowels(character, current_number_vowels);
	current_number_digits = number_digits(character, current_number_digits);
	current_number_alphas = number_alphas(character, current_number_alphas);
	current_number_lowers = number_lowers(character, current_number_lowers);
	current_number_uppers = number_uppers(character, current_number_uppers);
	current_number_spaces = number_spaces(character, current_number_spaces);
	current_number_alnums = number_alnums(character, current_number_alnums);
	current_number_puncts = number_puncts(character, current_number_puncts);
	print_int(outfile_ascii, ASCII_character);

	character = read_character(infile);
	ASCII_character = determine_ascii_value(character);
	current_number_lines = number_lines(character, current_number_lines);
	current_number_vowels = number_vowels(character, current_number_vowels);
	current_number_digits = number_digits(character, current_number_digits);
	current_number_alphas = number_alphas(character, current_number_alphas);
	current_number_lowers = number_lowers(character, current_number_lowers);
	current_number_uppers = number_uppers(character, current_number_uppers);
	current_number_spaces = number_spaces(character, current_number_spaces);
	current_number_alnums = number_alnums(character, current_number_alnums);
	current_number_puncts = number_puncts(character, current_number_puncts);
	print_int(outfile_ascii, ASCII_character);

	character = read_character(infile);
	ASCII_character = determine_ascii_value(character);
	current_number_lines = number_lines(character, current_number_lines);
	current_number_vowels = number_vowels(character, current_number_vowels);
	current_number_digits = number_digits(character, current_number_digits);
	current_number_alphas = number_alphas(character, current_number_alphas);
	current_number_lowers = number_lowers(character, current_number_lowers);
	current_number_uppers = number_uppers(character, current_number_uppers);
	current_number_spaces = number_spaces(character, current_number_spaces);
	current_number_alnums = number_alnums(character, current_number_alnums);
	current_number_puncts = number_puncts(character, current_number_puncts);
	print_int(outfile_ascii, ASCII_character);

	character = read_character(infile);
	ASCII_character = determine_ascii_value(character);
	current_number_lines = number_lines(character, current_number_lines);
	current_number_vowels = number_vowels(character, current_number_vowels);
	current_number_digits = number_digits(character, current_number_digits);
	current_number_alphas = number_alphas(character, current_number_alphas);
	current_number_lowers = number_lowers(character, current_number_lowers);
	current_number_uppers = number_uppers(character, current_number_uppers);
	current_number_spaces = number_spaces(character, current_number_spaces);
	current_number_alnums = number_alnums(character, current_number_alnums);
	current_number_puncts = number_puncts(character, current_number_puncts);
	print_int(outfile_ascii, ASCII_character);

	character = read_character(infile);
	ASCII_character = determine_ascii_value(character);
	current_number_lines = number_lines(character, current_number_lines);
	current_number_vowels = number_vowels(character, current_number_vowels);
	current_number_digits = number_digits(character, current_number_digits);
	current_number_alphas = number_alphas(character, current_number_alphas);
	current_number_lowers = number_lowers(character, current_number_lowers);
	current_number_uppers = number_uppers(character, current_number_uppers);
	current_number_spaces = number_spaces(character, current_number_spaces);
	current_number_alnums = number_alnums(character, current_number_alnums);
	current_number_puncts = number_puncts(character, current_number_puncts);
	print_int(outfile_ascii, ASCII_character);

	character = read_character(infile);
	ASCII_character = determine_ascii_value(character);
	current_number_lines = number_lines(character, current_number_lines);
	current_number_vowels = number_vowels(character, current_number_vowels);
	current_number_digits = number_digits(character, current_number_digits);
	current_number_alphas = number_alphas(character, current_number_alphas);
	current_number_lowers = number_lowers(character, current_number_lowers);
	current_number_uppers = number_uppers(character, current_number_uppers);
	current_number_spaces = number_spaces(character, current_number_spaces);
	current_number_alnums = number_alnums(character, current_number_alnums);
	current_number_puncts = number_puncts(character, current_number_puncts);
	print_int(outfile_ascii, ASCII_character);

	character = read_character(infile);
	ASCII_character = determine_ascii_value(character);
	current_number_lines = number_lines(character, current_number_lines);
	current_number_vowels = number_vowels(character, current_number_vowels);
	current_number_digits = number_digits(character, current_number_digits);
	current_number_alphas = number_alphas(character, current_number_alphas);
	current_number_lowers = number_lowers(character, current_number_lowers);
	current_number_uppers = number_uppers(character, current_number_uppers);
	current_number_spaces = number_spaces(character, current_number_spaces);
	current_number_alnums = number_alnums(character, current_number_alnums);
	current_number_puncts = number_puncts(character, current_number_puncts);
	print_int(outfile_ascii, ASCII_character);

	character = read_character(infile);
	ASCII_character = determine_ascii_value(character);
	current_number_lines = number_lines(character, current_number_lines);
	current_number_vowels = number_vowels(character, current_number_vowels);
	current_number_digits = number_digits(character, current_number_digits);
	current_number_alphas = number_alphas(character, current_number_alphas);
	current_number_lowers = number_lowers(character, current_number_lowers);
	current_number_uppers = number_uppers(character, current_number_uppers);
	current_number_spaces = number_spaces(character, current_number_spaces);
	current_number_alnums = number_alnums(character, current_number_alnums);
	current_number_puncts = number_puncts(character, current_number_puncts);
	print_int(outfile_ascii, ASCII_character);

	character = read_character(infile);
	ASCII_character = determine_ascii_value(character);
	current_number_lines = number_lines(character, current_number_lines);
	current_number_vowels = number_vowels(character, current_number_vowels);
	current_number_digits = number_digits(character, current_number_digits);
	current_number_alphas = number_alphas(character, current_number_alphas);
	current_number_lowers = number_lowers(character, current_number_lowers);
	current_number_uppers = number_uppers(character, current_number_uppers);
	current_number_spaces = number_spaces(character, current_number_spaces);
	current_number_alnums = number_alnums(character, current_number_alnums);
	current_number_puncts = number_puncts(character, current_number_puncts);
	print_int(outfile_ascii, ASCII_character);

	print_stats(outfile_stats, "Number Lines:", current_number_lines);
	print_stats(outfile_stats, "Number Vowels:", current_number_vowels);
	print_stats(outfile_stats, "Number Digits:", current_number_digits);
	print_stats(outfile_stats, "Number Alphas:", current_number_alphas);
	print_stats(outfile_stats, "Number Lowers:", current_number_lowers);
	print_stats(outfile_stats, "Number Uppers:", current_number_uppers);
	print_stats(outfile_stats, "Number Spaces:", current_number_spaces);
	print_stats(outfile_stats, "Number Alnums:", current_number_alnums);
	print_stats(outfile_stats, "Number Puncts:", current_number_puncts);

	fclose(infile);
	fclose(outfile_ascii);
	fclose(outfile_stats);

	return 0;
}