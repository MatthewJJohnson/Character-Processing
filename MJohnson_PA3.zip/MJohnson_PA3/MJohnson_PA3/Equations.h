/*
Programmer: Matthew J Johnson
Class: CptS 121, Spring  2016; Lab Section-09
Programming Assignment: Programming Assignment Three
Date: February 6, 2016
Description: This program performs character processing on 10 characters read in from a file, and writes the results to output files.
Collaborators: None
Revision History:	-Created 2:6:16
*/

#include <stdio.h>
#define NEWLINE 1
#define NOT_NEWLINE 0
#define VOWEL 2
#define NOT_VOWEL 0
#define NUMBER 3
#define NOT_NUMBER 0
#define ALPHA 4
#define NOT_ALPHA 0
#define LOWER 5
#define NOT_LOWER 0
#define UPPER 6
#define NOT_UPPER 0
#define NOT_WHITESPACE 0
#define WHITESPACE 7
#define ALNUM 8
#define NOT_ALNUM 0
#define PUNCT 9
#define NOT_PUNCT 0

FILE * open_input_file(void);
FILE * open_output_stats_file(void);
FILE * open_output_ascii_file(void);
char read_character(FILE *infile);
int determine_ascii_value(char character);
int is_line(char character);
int number_lines(char character, int current_number_lines);
int is_vowel(char character);
int number_vowels(char character, int current_number_vowels);
int is_digit(char character);
int number_digits(char character, int current_number_digits);
int is_alpha(char character);
int number_alphas(char character, int current_number_alphas);
int is_lower(char character);
int number_lowers(char character, int current_number_lowers);
int is_upper(char character);
int number_uppers(char character, int current_number_uppers);
int is_space(char character);
int number_spaces(char character, int current_number_spaces);
int is_alnum(char character);
int number_alnums(char character, int current_number_alnums);
int is_punct(char character);
int number_puncts(char character, int current_number_puncts);
void print_int(FILE *outfile_ascii, int number);
void print_stats(FILE *outfile_stats, char header[], int number);